import {  Component } from "@angular/core";

@Component({
selector:'app-simple-component',
template:`
<h2>Hi, I am Angular Component..!!</h2>
`
})
export class SimpleComponent{

}