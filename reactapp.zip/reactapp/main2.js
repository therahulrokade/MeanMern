// 1. Import React OM
import React from "react";
// 2. Import ReactDOM for rendering React Component in DOM
import ReactDom from "react-dom";
import "!style!css!bootstrap/dist/css/bootstrap.min.css";
import ProductUIComponent from "./components/application/productUIComponent.jsx";

ReactDom.render(<ProductUIComponent />, document.getElementById("app"));
