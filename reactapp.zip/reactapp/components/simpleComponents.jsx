import React, { Component } from "react";

class SimmpleComponent extends Component {
  // ctor will be used for state defination
  // to accept data from parent component
  //the "props" represent data to received from parent

  constructor(props) {
    super(props);
    // state declaration
    // event binding to component
  }

  // the render() method encapsulate DOM and its data with behaviour
  // this returns the DOM object aka Virtual Dom
  render() {
    return (
      <div>
        <h2> ~Mr. HellRider</h2>
        <br />
        <NewComponent />
      </div>
    );
  }
}

class NewComponent extends Component {
  render() {
    return (
      <div>
        <h2>You are rock Man!!!!!!!!</h2>
      </div>
    );
  }
}

export default SimmpleComponent;
