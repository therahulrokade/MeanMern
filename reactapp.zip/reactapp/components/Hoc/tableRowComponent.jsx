import React, { Component } from "react";

class TableRowComponent extends Component {
  render() {
    return (
      <tr>
        {/* {this.props.rec.map((v, i) => (
          <TableHeader idx={i} header={v} />
        ))} */}
         <td>{this.props.rec.id}</td>
         <td>{this.props.rec.name}</td>
      </tr>
    );
  }
}

class TableHeader extends Component {
  render() {
    <th>{this.props.header}</th>;
    <td>{this.props.idx}</td>;
  }
}

export default TableRowComponent;
