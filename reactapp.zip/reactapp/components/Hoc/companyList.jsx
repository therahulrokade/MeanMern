import React, { Component } from "react";
import TableRowComponent from "./tableRowComponent.jsx";

class CompanyListComponent extends Component {
  render() {
    return (
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            {/* {Object.keys(this.props.rec).forEach(header => {
              <TableHeader header={header} />;
            })} */}
          </tr>
        </thead>
        <tbody>
          {this.props.data.map((v, i) => (
            <TableRowComponent key={i} rec={v} />
          ))}
        </tbody>
      </table>
    );
  }
}

class TableHeader extends Component {
  render() {
    <td>{this.props.header}</td>;
  }
}

export default CompanyListComponent;
