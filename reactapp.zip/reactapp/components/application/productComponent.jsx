import React, { Component } from "react";

class ProductComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ProductId: 0,
      ProductName: "",
      Price: 0,
      CategotyName: "",
      Manufacture: "",
      Products: [
        {
          ProductId: 101,
          ProductName: "Laptop",
          Price: 273546,
          CategoryName: "Sony",
          Manufacture: "Sony ltd"
        },
        {
          ProductId: 102,
          ProductName: "Mobile",
          Price: 75856,
          CategoryName: "Note 4",
          Manufacture: "MI"
        },
        {
          ProductId: 103,
          ProductName: "Fan",
          Price: 7568,
          CategoryName: "ABC",
          Manufacture: "abc system"
        }
      ],
      Categories: ["Electronics", "Electrical", "Food"],
      Manufacturers: ["Ab Tech", "CD Power", "EF Beverages"]
    };
  }

  // e is event-payload raised on target element
  // we can read the payload data using 'e'
  onChangeProductId(e) {
    this.setState({ ProductId: e.target.value });
  }

  onChangeProductName(e) {
    this.setState({ ProductName: e.target.value });
  }

  onChangePrice(e) {
    this.setState({ Price: e.target.value });
  }

  onChangeCategoryName(e) {
    this.setState({ CategotyName: e.target.value });
  }

  onChangeManufacturer(e) {
    this.setState({ Manufacture: e.target.value });
  }

  onClickClear(e) {
    this.setState({ ProductId: 0 });
    this.setState({ ProductName: "" });
    this.setState({ Price: 0 });
    this.setState({ CategotyName: "" });
    this.setState({ Manufacture: "" });
  }

  getSelectedProduct(e) {
    this.setState({
      ProductId: e.ProductId,
      ProductName: e.ProductName,
      Price: e.Price,
      CategoryName: e.CategoryName,
      Manufacture: e.Manufacture
    });
  }

  onClickSave(e) {
    alert(
      `${this.state.ProductId} ${this.state.ProductName} ${this.state.Price} ${
        this.state.CategotyName
      } ${this.state.Manufacture}`
    );

    // 1. get the copy of the Products array using slice()
    let tempArray = this.state.Products.slice();

    // 2. push the new record in to the tempArray
    tempArray.push({
      ProductId: this.state.ProductId,
      ProductName: this.state.ProductName,
      Price: this.state.Price,
      CategoryName: this.state.CategoryName,
      Manufacture: this.state.Manufacture
    });

    // 3.copy the temp array into products array
    this.setState({ Products: tempArray });
  }

  render() {
    return (
      <div className="container bg-light">
        <h1 className="text-center text-info">Product Info</h1>
        <hr />
        <div className="form-group">
          <label htmlFor="ProductId">ProductID</label>
          <input
            type="text"
            className="form-control"
            value={this.state.ProductId}
            onChange={this.onChangeProductId.bind(this)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="ProductName">ProductName</label>
          <input
            type="text"
            className="form-control"
            value={this.state.ProductName}
            onChange={this.onChangeProductName.bind(this)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="Price">Price</label>
          <input
            type="text"
            className="form-control"
            value={this.state.Price}
            onChange={this.onChangePrice.bind(this)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="CategoryName">Category Name</label>
          <select
            className="form-control"
            value={this.state.CategotyName}
            onChange={this.onChangeCategoryName.bind(this)}
          >
            {this.state.Categories.map((c, i) => (
              <Options key={i} data={c} />
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="Manufacturer">Manufacturer</label>
          <select
            className="form-control"
            value={this.state.Manufacture}
            onChange={this.onChangeManufacturer.bind(this)}
          >
            {this.state.Manufacturers.map((c, i) => (
              <Options key={i} data={c} />
            ))}
          </select>
        </div>
        <div className="form-group">
          <table>
            <tbody>
              <tr>
                <td>
                  <input
                    type="button"
                    value="Clear"
                    className="btn btn-primary"
                    onClick={this.onClickClear.bind(this)}
                  />
                </td>
                <td>
                  <input
                    type="button"
                    value="Save"
                    className="btn btn-success"
                    onClick={this.onClickSave.bind(this)}
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="container">
          <table className="table table-bordered table-striped">
            <thead>
              <tr>
                {this.state.Products.map((header, idx) => {
                  <TableHeader header={header} />;
                })}
                {/* { <th>ProductID</th>
                <th>ProductName</th>
                <th>Product Price</th>
                <th>Product Category</th>
                <th>Product Manufacture</th> } */}
              </tr>
            </thead>
            <tbody>
              {this.state.Products.map((prd, idx) => (
                <TableRow
                  key={idx}
                  row={prd}
                  selected={this.getSelectedProduct.bind(this)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

// component that will render option
// props data is the data passed from oarent
class Options extends Component {
  render() {
    return <option value={this.props.data}>{this.props.data}</option>;
  }
}

class TableHeader extends Component {
  render() {
    <th value={this.props.header}>{this.props.header}</th>;
  }
}

class TableRow extends Component {
  constructor(props) {
    super(props);
  }

  onRowClick() {
    props.selected(this.props.row);
  }

  render() {
    return (
      <tr onClick={this.onRowClick.bind(this)}>
        <td>{this.props.row.ProductId}</td>
        <td>{this.props.row.ProductName}</td>
        <td>{this.props.row.Price}</td>
        <td>{this.props.row.CategoryName}</td>
        <td>{this.props.row.Manufacture}</td>
      </tr>
    );
  }
}

export default ProductComponent;
