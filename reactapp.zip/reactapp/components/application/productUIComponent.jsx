import React, { Component } from "react";
import ProductService from "./../../services/service.js";

class ProductUIComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      _id: "",
      ProductId: 0,
      ProductName: "",
      CategotyName: "",
      Manufacturer: "",
      Price: 0,
      Products: [
        {
          //_id: "23456",
          ProductId: 101,
          ProductName: "Laptop",
          CategoryName: "Sony",
          Manufacturer: "Sony ltd",
          Price: 273546
        },
        {
          //_id: "23456",
          ProductId: 102,
          ProductName: "Mobile",
          CategoryName: "Note 4",
          Manufacturer: "MI",
          Price: 75856
        },
        {
          //_id: "23456",
          ProductId: 103,
          ProductName: "Fan",
          CategoryName: "ABC",
          Manufacturer: "abc system",
          Price: 6548
        }
      ],
      Categories: ["Electronics", "Electrical", "Food"],
      criteriaName: "",
      CriteriaNames: [
        "ProductId",
        "ProductName",
        "CategoryName",
        "Manufacturer",
        "Price"
      ],
      Manufacturers: ["Ab Tech", "CD Power", "EF Beverages"],
      sort: false,
      Reverse: false
    };

    this.serv = new ProductService();
  }

  // e is event-payload raised on target element
  // we can read the payload data using 'e'
  onChangeProduct(e) {
    this.setState({ [e.target.name]: e.target.value }, () => {});
  }

  onChangeCategoryName(e) {
    this.setState({ CategotyName: e.target.value });
  }

  onChangeManufacturer(e) {
    this.setState({ Manufacturer: e.target.value });
  }

  // bind with Criteria Name
  onChangeCriteria(e) {
    this.setState({ criteriaName: e.target.value });
  }

  onClickClear(e) {
    this.setState({ _id: "" });
    this.setState({ ProductId: 0 });
    this.setState({ ProductName: "" });
    this.setState({ CategotyName: "" });
    this.setState({ Manufacturer: "" });
    this.setState({ Price: 0 });
  }

  onClickSort(e) {
    let temp = this.state.Products;
    let type = this.state.criteriaName;

    //console.log(type);
    temp.sort(function(a, b) {
      if (typeof a[type] == "string") {
        return a[type].toLowerCase().localeCompare(b[type].toLowerCase());
      } else {
        return a[type] - b[type];
      }
    });
    this.setState({ sort: false });
    this.setState({ Products: temp });
  }

  onClickReverse(e) {
    let temp = this.state.Products;

    let array = temp.reverse();

    this.setState({ Products: array });
  }

  getSelectedProduct(e) {
    this.setState({
      _id: e._id,
      ProductId: e.ProductId,
      ProductName: e.ProductName,
      CategoryName: e.CategoryName,
      Manufacturer: e.Manufacturer,
      Price: e.Price
    });
  }

  onClickUpdate(e) {
    let id = this.state.ProductId;
    let prd = {
      ProductId: this.state.ProductId,
      ProductName: this.state.ProductName,
      CategoryName: this.state.CategoryName,
      Manufacturer: this.state.Manufacturer,
      Price: this.state.Price
    };

    this.serv
      .updateData(id, prd)
      .then(res => res.json())
      .then(resp => resp.data)
      .catch(error => console.log(error.status));
  }

  onClickSave(e) {
    alert(
      `${this.state.ProductId} ${this.state.ProductName} ${this.state.Price} ${
        this.state.CategotyName
      } ${this.state.Manufacture}`
    );

    let prd = {
      ProductId: this.state.ProductId,
      ProductName: this.state.ProductName,
      CategoryName: this.state.CategoryName,
      Manufacturer: this.state.Manufacturer,
      Price: this.state.Price
    };

    this.serv
      .postData(prd)
      .then(res => res.json())
      .then(resp => resp.data)
      .catch(error => console.log(error.status));
  }

  deleteData(row) {
    let prds = this.serv
      .deleteData(row.ProductID)
      .then(data => data.json())
      .then(value => {
        console.log(JSON.stringify(value.data));

        // let tempArray = this.state.Products.slice();
        // tempArray.pop(resp.data);
        // this.setState({Products:tempArray});
      })
      .catch(error => {
        console.log(`Error Occured  ${error.status}`);
      });
  }

  // method will be executed immediatly after the render() completes its job
  componentDidMount() {
    let prds = this.serv
      .getData()
      .then(Data => Data.json())
      .then(value => {
        //console.log(JSON.stringify(value));
        this.setState({ Products: value.data });
      });
  }

  render() {
    return (
      <div className="container bg-light">
        <h1 className="text-center text-info">Product Info</h1>
        <hr />
        <div className="form-group">
          <label htmlFor="_id">_ID</label>
          <input
            type="text"
            className="form-control"
            name="_id"
            value={this.state._id}
            onChange={this.onChangeProduct.bind(this)}
            disabled
          />
        </div>
        <div className="form-group">
          <label htmlFor="ProductId">ProductID</label>
          <input
            type="text"
            className="form-control"
            name="ProductId"
            value={this.state.ProductId}
            onChange={this.onChangeProduct.bind(this)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="ProductName">ProductName</label>
          <input
            type="text"
            className="form-control"
            name="ProductName"
            value={this.state.ProductName}
            onChange={this.onChangeProduct.bind(this)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="CategoryName">Category Name</label>
          <select
            className="form-control"
            value={this.state.CategoryName}
            name="CategoryName"
            onChange={this.onChangeCategoryName.bind(this)}
          >
            <option value="Select Category">Select Category</option>
            {this.state.Categories.map((c, i) => (
              <Options key={i} data={c} />
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="Manufacturer">Manufacturer</label>
          <select
            className="form-control"
            value={this.state.Manufacturer}
            name="Manufacturer"
            onChange={this.onChangeManufacturer.bind(this)}
          >
            {this.state.Manufacturers.map((c, i) => (
              <Options key={i} data={c} />
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="Price">Price</label>
          <input
            type="text"
            className="form-control"
            name="Price"
            value={this.state.Price}
            onChange={this.onChangeProduct.bind(this)}
          />
        </div>
        <div className="form-group">
          <table>
            <tbody>
              <tr>
                <td>
                  <input
                    type="button"
                    value="Save"
                    className="btn btn-success m-3"
                    onClick={this.onClickSave.bind(this)}
                  />
                </td>
                <td>
                  <input
                    type="button"
                    value="update"
                    className="btn btn-primary m-3"
                    onClick={this.onClickUpdate.bind(this)}
                  />
                </td>
                <td>
                  <input
                    type="button"
                    value="Clear"
                    className="btn btn-danger m-3"
                    onClick={this.onClickClear.bind(this)}
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <hr />
        <div className="form-group">
          <label htmlFor="criteriaName">Criteria Operation</label>
          <select
            name="criteriaName"
            className="form-control"
            value={this.state.criteriaName}
            onChange={this.onChangeCriteria.bind(this)}
          >
            {this.state.CriteriaNames.map((c, i) => (
              <Options key={i} data={c} />
            ))}
          </select>

          <table>
            <tbody>
              <tr>
                <td>
                  <input
                    type="radio"
                    value={this.state.sort}
                    name="group"
                    className="btn btn-success m-3"
                    onClick={this.onClickSort.bind(this)}
                  />
                  Sort
                  <input
                    type="radio"
                    value={this.state.Reverse}
                    name="group"
                    className="btn btn-warning m-3"
                    onClick={this.onClickReverse.bind(this)}
                  />
                  Reverse
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <hr />
        <div className="container">
          <table className="table table-bordered table-striped">
            <thead>
              <tr>
                {Object.keys(this.state.Products[0]).map((header, idx) => (
                  <TableHeader key={idx} header={header} />
                ))}
              </tr>
            </thead>
            <tbody>
              {this.state.Products.map((prd, idx) => (
                <TableRow
                  key={idx}
                  row={prd}
                  selected={this.getSelectedProduct.bind(this)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

// component that will render option
// props data is the data passed from parent
class Options extends Component {
  render() {
    return <option value={this.props.data}>{this.props.data}</option>;
  }
}

class TableHeader extends Component {
  render() {
    return <th>{this.props.header}</th>;
  }
}

class TableRow extends Component {
  constructor(props) {
    super(props);
  }

  onRowClick() {
    this.props.selected(this.props.row);
  }
  onClickDelete() {
    //alert("Record deleted")
    this.props.deleterow(this.props.row);
  }

  render() {
    return (
      <tr onClick={this.onRowClick.bind(this)}>
        <td>{this.props.row._id}</td>
        <td>{this.props.row.ProductId}</td>
        <td>{this.props.row.ProductName}</td>
        <td>{this.props.row.CategoryName}</td>
        <td>{this.props.row.Manufacturer}</td>
        <td>{this.props.row.Price}</td>
        <td>
          <td>
            <input
              type="button"
              className="btn btn-danger"
              value="Delete"
              onClick={this.onClickDelete.bind(this)}
            />
          </td>
        </td>
      </tr>
    );
  }
}

export default ProductUIComponent;
